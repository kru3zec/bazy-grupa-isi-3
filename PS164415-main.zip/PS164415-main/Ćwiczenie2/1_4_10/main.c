#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    scanf("%d",&n);
    int i=0;
    while(i*i<=a)
    {
        i++;
    }
    printf("%d\n",i-1);
    return 0;
}
