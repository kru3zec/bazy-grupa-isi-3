#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, m, nwd=1, max;
    printf("Podaj liczbe calkowita n");
    scanf("%d",&n);
    printf("Podaj liczbe calkowita m");
    scanf("%d",&m);
    max=(n>m)?n:m;
    for(int i=2;i<=max;i++)
        if ((n % i==0)&&(m % i==0))
        nwd=i;
    printf("NWD liczb %d i %d wynosi %d\n",n,m,nwd);
    return 0;
}
