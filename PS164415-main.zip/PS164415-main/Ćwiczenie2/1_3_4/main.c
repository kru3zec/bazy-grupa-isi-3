#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    int b;
    printf("Podaj pierwsza liczbe");
    scanf("%d",&a);
    printf("Podaj drug� liczbe");
    scanf("%d",&b);
   if(abs(a)>abs(b))
    printf("%d",abs(a));
   else
    printf("%d",abs(b));
    return 0;
}
