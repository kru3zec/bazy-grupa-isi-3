#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,a,b,h,p;
    printf("Pole jakiej figury chcesz policzya?\n 1-kwadrat\n 2-trojkat\n 3-prostokat");
    scanf("%d",&i);
    switch(i)
    {
        case 1: printf("podaj dlugosc boku kwadratu");
                scanf("%d",&a);
                p=a*a;
                break;
        case 2: printf("Podaj dlugosc boku i wysokosc trojkata");
                scanf("%d %d",&a,&h);
                p=0.5*a*h;
                break;
        case 3: printf("podaj dlugosc bokow prostokata");
                scanf("%d %d",&a,&b);
                p=a*b;
    }
    printf("Pole figury o podanych wymiarach wynosi %d\n",p);
}
