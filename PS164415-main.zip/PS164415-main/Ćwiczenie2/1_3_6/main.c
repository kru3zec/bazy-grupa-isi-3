#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a,b,c,d,e,f;
    printf("Podaj liczby a b c d e f");
    scanf("%d %d %d %d %d %d", &a,&b,&c,&d,&e,&f);
    if(a==0 &&b==0 && c==0 && d==0 &&e==0 &&f==0)
        printf("wszystkie wyznaczniki sa r�one 0");
    else
    {
        float W,Wx,Wy,x,y;
        W = a * d - b * c;
        Wx = e * d - b * f;
        Wy = a * f - e * c;
        if(W!=0)
    {
            x=Wx/W;
            y=Wy/y;
            printf("x= %d, y= %d", x, y);
        }
        else
        {
            if( Wx == 0 && Wy == 0 ) printf( "Uklad ma nieskonczenie wiele rozwiazan!" );
            else printf( "Uklad nie ma rozwiazan!" );
        }
    }
    return 0;
}
