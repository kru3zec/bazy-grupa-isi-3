#include <stdio.h>
#include <stdlib.h>

int main()
{
unsigned int in;
unsigned int sum=0;

scanf("%d", &in);

for(int i=1; i< in+1; i ++)
    {
        sum+=i*i;
    }
printf("%i", sum);
return 0;

}
