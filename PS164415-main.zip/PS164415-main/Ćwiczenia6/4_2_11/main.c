#include <stdio.h>
#include <stdlib.h>

double iloczyn_skalarny(double* t1, double* t2, int n){
  double suma = 0;
  for (int x = 0; x <= n; x++){
    suma += t1[x] * t2[x];
  }
  return suma;
}

int main()
{
    int tablica[3]={7,8,9};
    int tablica2[3]={4,5,6};

    printf("%f"),iloczyn_skalarny(3,tablica,tablica2);

    return 0;
}
