#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void sito(bool *tab, unsigned int n)
{
	for (int i=2; i*i<=n; i++)
    {

        if(!tab[i])
        for (int j = i*i ; j<=n; j+=i)
            tab[j] = 1;
    }
}


int main()
{
    int tablica[4]={2,4,6,3};
    sito(tablica, 4);
    printf("Hello world!\n");
    return 0;
}
