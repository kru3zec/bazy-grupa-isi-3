#include <stdio.h>
#include <stdlib.h>

void przypisywanie(int n, int tab[],int tab2[],int tab3[])
{
    for(int i=0;i<n;i++)
    {
        tab3[i]= tab2[i]+tab[i];
    }
}
void wiekszy(int n, int tab[], int tab2[], int tab3[])
{
    for(int i=0;i<n;i++)
    {
        if(tab2[i]<tab[i])
            tab3[i]=tab[i];
        else
            tab3[i]=tab2[i];
    }
}

void zamiana(int n, int tab[],int tab2[],int tab3[])
{
    int i;
    int tem;
    for( i=0;i<n;i++)
    {
        tem=tab[i];
        tab[i]=tab3[i];
        tab3[i]=tab2[i];
        tab2[i]=tem;
    }
}

int main()
{
    int tablica[3]={7,8,9};
    int tablica2[3]={4,5,6};
    int tablica3[3]= {1,2,3};
    zamiana(3,tablica,tablica2, tablica3);
    for(int i=0;i<3;i++)
    {
        printf("[%d]= %d\n",i,tablica3[i]);
    }
    for(int i=0;i<3;i++)
    {
        printf("[%d]= %d\n",i,tablica2[i]);
    }
    for(int i=0;i<3;i++)
    {
        printf("[%d]= %d\n",i,tablica[i]);
    }
    return 0;
}
