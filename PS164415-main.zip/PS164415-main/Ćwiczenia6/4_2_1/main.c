#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void zerowanie (unsigned int n, int * tab )
{
    int i;
    for(i=0;i<n;i++)
        tab[i]=0;
}
void inicjuj (unsigned int n, int * tab)
{
    int i;
    for(i=0;i<n;i++)
        tab[i]=i;
}
void podwajanie(unsigned int n, int tab[])
{
    for(int i=0;i<n;i++)
    {
        tab[i]=2*tab[i];
    }
}
void bezwzgledna(int n, int tab[])
{
    for(int i=0;i<n;i++)
    {
        tab[i]=abs(tab[i]);
    }
}

int main()
{
    int tablica[4];
    zerowanie(4,tablica);
    inicjuj(4,tablica);
    podwajanie(4,tablica);
    bezwzgledna(4,tablica);
    for(int i=0;i<4;i++)
    {
        printf("[%d]= %d\n",i,tablica[i]);
    }
    printf("Hello world!\n");
    return 0;
}
