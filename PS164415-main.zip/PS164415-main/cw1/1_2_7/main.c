#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
    scanf("%d",&x);
    int a= x+1;
    printf("%d",a);
    return 0;
}
