#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double x;
    scanf("%lf",&x);
    printf("%f",sqrt(x));
    return 0;
}
