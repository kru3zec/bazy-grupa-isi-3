#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a;
    scanf("%f",&a);
    printf("%.2f",a);
    return 0;
}
