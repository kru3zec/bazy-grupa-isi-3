#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Napis zawierajacy bardzo dziwne znaczki // \\ \\ & %% $\n");
    return 0;
}
