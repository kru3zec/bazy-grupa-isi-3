#include <stdio.h>
#include <stdlib.h>

int main()
{
    int liczba1,liczba2,liczba3;
    scanf("%d",&liczba1);
    scanf("%d",&liczba3);
    scanf("%d",&liczba2);
    printf("%d\n%d\n%d\n", liczba1,liczba2,liczba3);
    return 0;
}
