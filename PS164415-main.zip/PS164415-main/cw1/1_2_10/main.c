#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    scanf("%d",&a);
    printf("%d",a*-1);
    return 0;
}
