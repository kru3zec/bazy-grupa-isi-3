#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a;
    printf ("Wpisz liczbe z przecinkiem: ");
    scanf ("%f", &a);
    printf ("Liczba to: %.0e-1\n", a);
    return 0;
}
