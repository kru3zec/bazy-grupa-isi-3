#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c;
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    float srednia =(a+b+c)/3.0;
    printf("%f",srednia);
    return 0;
}
