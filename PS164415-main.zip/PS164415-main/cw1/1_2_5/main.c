#include <stdio.h>
#include <stdlib.h>

int main()
{
    double liczba;
    scanf("%lf", &liczba);
    printf("%f", liczba);
    return 0;
}
