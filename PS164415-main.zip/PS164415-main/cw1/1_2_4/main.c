#include <stdio.h>
#include <stdlib.h>

int main()
{
    int liczba;
    scanf("%d",&liczba);
    printf("%d",liczba);
    return 0;
}
