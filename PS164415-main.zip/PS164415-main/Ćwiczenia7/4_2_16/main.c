#include <stdio.h>
#include <stdlib.h>
 void foo(double*wsk)
 {
     free(wsk);
 }
int main()
{
    double * tablica = malloc(4*sizeof(double));
    foo(tablica);
    printf("%p\n",tablica);
    printf("Hello world!\n");
    return 0;
}
