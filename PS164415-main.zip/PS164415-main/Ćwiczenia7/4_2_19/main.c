#include <stdio.h>
#include <stdlib.h>

int* foo(int n, int tab[])
{
    int licznik = 0;
    for(int i=0;i<n;i++)
    {
        if(tab[i]!=0)
        {
            licznik++;
        }
    }
    int* tab2=malloc(n*sizeof(int));
    int j=0;
    for(int i=0;i<n;i++)
    {
        if(tab[i]!=0)
        {
            *(tab2+j)=tab[i];
            j++;
        }

    }
    return tab2;
}

int main()
{
    int tablica[]= {3,6,7,-11};
    int * wsk =foo(4,tablica);
    for(int i =0; i<4;i++)
    {
        printf("[%d] = %d\n"),i,*(wsk+1);
    }
    return 0;
}
