#include <stdio.h>
#include <stdlib.h>

int zamiana(a,b)
{
    int temp=a;
    a=b;
    b=temp;
    return a,b;
}

int main()
{
    int a, b;
    printf("Podaj pierwsza liczbe: ");
    scanf("%d",&a);
    printf("Podaj druga liczbe:" );
    scanf("%d",&b);
    printf("%d %d",a,b);
    return 0;
}
