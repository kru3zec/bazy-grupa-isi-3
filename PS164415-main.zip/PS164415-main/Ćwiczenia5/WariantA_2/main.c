#include <stdio.h>
#include <stdlib.h>

unsigned int ciag(unsigned int n)
{
    if (n<=2)
        return 1;
    switch(n%2)
    {
        case 0: return ciag(n-1) + n;
        case 1: return 2* ciag(n-1) - n;
    }
}

int main()
{
    int n;
    printf("Podaj n:");
    scanf("%d",&n);
    printf("%d\n",ciag(n));
    return 0;
}
