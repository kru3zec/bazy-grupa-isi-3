#include <stdio.h>
#include <stdlib.h>

int silnia(unsigned int liczba)
{
    int i,sil=1;
    for(i=2;i<=liczba;i++)
        sil*=i;
    return sil;
}

int main()
{
    int n;
    printf("podaj liczbe calkowita");
    scanf("%d",&n);
    printf("silnia z %d = %d\n",n,silnia(n));
    return 0;
}
