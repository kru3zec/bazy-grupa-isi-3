#include <stdio.h>
#include <stdlib.h>
#include<math.h>

int potegowanie(int n)
{
    int potega=1;
    for(int i=1;i<=n;i++)
    {
        potega*=2;
    }
    return potega;
}

int main()
{
    int w;
    scanf("%d",&w);
    printf("%d",potegowanie(w));
    return 0;
}
