#include <stdio.h>
#include <stdlib.h>

unsigned int NWD(unsigned int n, unsigned int m)
{
    if(n==m)
        return m;
    if(n > m)
        return NWD(n%m,m);
    else
        return NWD(m%n, n);
}

int main()
{
    int n,m;
    scanf("%d %d",&n,&m);
    printf("%d",NWD(n,m));
    return 0;
}
