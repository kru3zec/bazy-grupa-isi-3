#include <stdio.h>
#include <stdlib.h>

void funkcja(int n,int *w) {
    *w = n;
}

int main()
{
    int x=2;
    int y=0;
    funkcja(x,&y);
    printf("%d\n",y);
    return 0;
}
