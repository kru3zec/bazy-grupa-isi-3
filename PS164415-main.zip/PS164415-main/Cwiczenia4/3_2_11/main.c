#include <stdio.h>
#include <stdlib.h>

int *alokuj(unsigned int n)
{
    return malloc(n*sizeof(int));
}

int main()
{
    printf("%d",*alokuj(2));
    return 0;
}
