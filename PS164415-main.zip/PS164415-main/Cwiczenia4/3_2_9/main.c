#include <stdio.h>
#include <stdlib.h>

int *alokuj()
{
    return malloc(sizeof(int));
}

int main()
{
    printf("%d",*alokuj(2));
    return 0;
}
