#include <stdio.h>
#include <stdlib.h>

void przepisz(int const *a,int *b)
{
    *b=*a;
}

int main()
{
    int a=1;
    int b=12;
    przepisz(&a,&b);
    printf("%d\n",a);
    return 0;
}
