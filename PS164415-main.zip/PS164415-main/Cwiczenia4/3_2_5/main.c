#include <stdio.h>
#include <stdlib.h>

int suma(int const *a,int const *b)
{
    return *a+*b;
}

int main()
{
    int a=1;
    int b=2;
    printf("%d\n",suma(&a,&b));
    return 0;
}
