#include <stdio.h>
#include <stdlib.h>
int* mniejsza(int * a,int *b)
{
    if(*a<*b)
        return a;
    else
        return b;
}

int main()
{
    int x=4,y=8;
    printf("%p\n",mniejsza(&x,&y));
    return 0;
}
