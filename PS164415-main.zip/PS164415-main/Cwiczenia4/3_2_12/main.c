#include <stdio.h>
#include <stdlib.h>

double *reserve(int unsigned n)
{
    return malloc(n*sizeof(int));
}

int main()
{
    printf("%p", reserve(7));
    return 0;
}

